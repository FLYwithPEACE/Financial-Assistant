<?php  include "includes/db.php"; ?>
<?php  include "includes/header.php"; ?>






<!-- Navigation -->

<?php  include "includes/navigation.php"; ?>

<?php


if(isset($_POST['update'])) {
    $toUpdate = array();
    ?>
    <div class="personalized-form-container">

    <div class="alert alert-success text-center" role="alert">
         Saved changes.
    </div>
</div>
    <?php
    
    
   // echo "Submitted";
       foreach($_POST['checkBoxArray'] as $postValueId ){
           //echo $postValueId;
           array_push($toUpdate, $postValueId);
           
       }
    //print_r($toUpdate);
    
     $query = "SELECT * FROM s_categories";
    $select_all_posts_query = mysqli_query($connection,$query);

    while($row = mysqli_fetch_assoc($select_all_posts_query)) {
        extract($row);
     //Loops see if the id is the same 
        $statusToUpdate="OFF";
        foreach ($toUpdate as $id_toUpdate){
            
            if($s_cat_id==$id_toUpdate){
                //echo "Gonna update since:".$s_cat_id."==".$id_toUpdate;
                 $statusToUpdate="ON";  
                
                
            }
        }
        
        $query = "UPDATE s_categories SET s_cat_status = '{$statusToUpdate}' WHERE s_cat_id = {$s_cat_id}  ";
        //echo($query);
        $update_to_published_status = mysqli_query($connection,$query); 
        
    }
    
    //Gets all the database, and updates the values correspondiesnts
    
}


?>


<!-- Page Content -->
<div class="container">

    <a href="./stocks.php ">
        <p>Go Back to Stocks</p>
    </a>
    <hr>

    <div class="block-title">
        <h2>Stock Table Settings</h2>
    </div>


    <hr>

    <form action="#" method="post" role="form">
        <div class="form-group">
            <p></p>
            <div class="col-md-9">

                <?php 
                function echoCheckedIf($s_cat_status) {
                    if($s_cat_status=="ON"){
                        echo "checked";
                    }

                    
                }        
                
                
                         $query = "SELECT * FROM s_categories";
                        $select_all_posts_query = mysqli_query($connection,$query);

                        while($row = mysqli_fetch_assoc($select_all_posts_query)) {
                            extract($row);
//                            echo "found";
//                                echo $w_stock_name;
                            
//                            $currentStock=setOtherStock($w_stock_name);
//                            
//                            //echo "calling";
//$stock_pred_current = setOtherStock_pred($w_stock_name);

                            
                            
                            
                            ?>



                <label class="checkbox-inline" for="example-inline-checkbox3">

                    <input class='checkBoxes' <?php echoCheckedIf($s_cat_status) ?> type='checkbox' name='checkBoxArray[]' value="<?php echo $s_cat_id; ?>"> <?php echo $s_cat_name; ?>
                </label>

                <?php 
                        }
                ?>

                <hr>
                <div class="form-group mx-sm-3 mb-2">
                    <button type="submit" name="update" class="btn btn-medium btn-primary mb-2">Save changes</button>
                </div>
            </div>
        </div>
    </form>

    <?php include "includes/footer.php";?>

</div> <!-- /.container -->
