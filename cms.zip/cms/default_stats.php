<?php  include "includes/db.php"; ?>
<?php  include "includes/header.php"; ?>


<?php

$json_pred = file_get_contents('./default_api.json');
$json_a_pred = (json_decode($json_pred, true));
//var_dump($json_a_pred);
if ($json_a_pred === null) {
    // deal with error...
    echo "There is an error on the decoding";
}

$count_total=0;

$def_count_total=0;
//less or equal
$def_count_25=0;
$def_count_50=0;
$def_count_50_plus=0;


$def_sex_male=0;
$def_sex_female=0;

$def_education_graduateSchool=0;
$def_education_university=0;
$def_education_highSchool=0;
$def_education_others=0;
$def_education_uknown=0;

$def_marriage_married=0;
$def_marriage_single=0;
$def_marriage_married=0;



foreach ($json_a_pred as $base => $atributes) {

//    echo $base;
//    echo $atributes[0]["undefined"];
//    echo $atributes[0]["X1"];
    
    foreach ($atributes as $id => $col) {
        $count_total=$count_total+1;
    //prints all from the X1
//    echo $atributes["X1"];//Throws all the X1's
        //echo $col["Y"];
        if($col["Y"]=="1"){
            //the defaulted people
            //echo $attributes["Y"];
            $def_count_total=$def_count_total+1;
        }
        $temp_age = $col["X5"];
        if($temp_age<=25){
            $def_count_25=$def_count_25+1;
        }
        else if($temp_age<=50){
            $def_count_50=$def_count_50+1;
        }
        else if($temp_age>50){
            $def_count_50_plus=$def_count_50_plus+1;
        }
        //sex
        if($col["X2"]=="1"){
            $def_sex_male=$def_sex_male+1;
        }else{
            $def_sex_female=$def_sex_female+1;
        }
        
        //education
        $temp_education=$col["X3"];
        if($temp_education==1){
            $def_education_graduateSchool=$def_education_graduateSchool+1;
        }
        else if($temp_education==2){
            $def_education_university=$def_education_university+1;
        }
        else if($temp_education==3){
            $def_education_highSchool=$def_education_highSchool+1;
        }
        else if($temp_education==4){
            $def_education_others=$def_education_others+1;
        }
        else if($temp_education>=5){
            $def_education_uknown+1;
        }
        
    }
}
//
//
//echo "education level: ".$def_education_graduateSchool." ".$def_education_university." ".$def_education_highSchool." ".$def_education_others." ".$def_education_uknown;
//echo $def_count_total." ".$def_count_25." ".$def_count_50." ".$def_count_50_plus;



//class Stock_pred{
//    public $name;
//    public $price;
//    public $status;
//}
//
//
//$stocks_pred_array =array();
//foreach ($json_a_pred as $id => $atributes) {
//    $theStock = new Stock_pred;
//    $theStock->name=strval($id);
//    
//    $theStock->price=strval($atributes["Price"]);
//    
////    echo $atributes["Status"];
//    $results = "UNDEFINED";
//    if(strval($atributes["Status"])=="POSITIVE"){
//        
//        $results = "Looks safe";
//        
//    }else{
//        $results = "Be careful";
//        
//    }
//    $theStock->status=($results);
//    
//    
//    $theStock->status=strval($results);
////    echo "results out".$theStock->status;
//    
//     array_push($stocks_pred_array,$theStock);
//}



?>



<!-- Navigation -->

<?php  include "includes/navigation.php"; ?>

<style>
    .custom-container {
        align-content: center;
        
        padding-left: 3%;
        padding-right: 3%;
    }
    
    @media (min-width: @screen-md-min) { 
     .title{
        padding-left: 15%;
    }
    }
    
   

</style>

<div class="container custom-container">

   
    <a href="./default_assist.php">
        <p>Go Back to Default Assistant</p>
    </a>
    <hr>
    <div class="block-title md-text-center title">
        <h2>Defaulted People Stats</h2>

    </div>


    <div class="">
        <div class="row">
            <div class="col-md-6">
                <div id="piechart-age"></div>
            </div>
            <div class="col-md-6">.<div id="piechart-sex"></div>
            </div>
            <div class="col-md-6">
                <div id="piechart-education"></div>
            </div>
        </div>
    </div>
</div>


<!-- Page Content -->






<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript">
    // Load google charts
    google.charts.load('current', {
        'packages': ['corechart']
    });
    google.charts.setOnLoadCallback(drawChartAge);
    google.charts.setOnLoadCallback(drawChartSex);
    google.charts.setOnLoadCallback(drawChartEducation);

    // Draw the chart and set the chart values
    function drawChartAge() {
        var data = google.visualization.arrayToDataTable([
            ['Age Range', 'people'],
            [' < 26 yrs', <?php echo $def_count_25; ?>],
            ['< 50', <?php echo $def_count_50; ?>],
            ['> 50', <?php echo $def_count_50_plus; ?>],
        ]);

        // Optional; add a title and set the width and height of the chart
        var options = {
            'title': 'Age',
            'width': 550,
            'height': 400
        };

        // Display the chart inside the <div> element with id="piechart"
        var chart = new google.visualization.PieChart(document.getElementById('piechart-age'));
        chart.draw(data, options);
    }

    function drawChartSex() {
        var data = google.visualization.arrayToDataTable([
            ['Sex', 'people'],
            ['male', <?php echo $def_sex_male; ?>],
            ['female', <?php echo $def_sex_female; ?>],
        ]);

        // Optional; add a title and set the width and height of the chart
        var options = {
            'title': 'Sex',
            'width': 550,
            'height': 400
        };

        // Display the chart inside the <div> element with id="piechart"
        var chart = new google.visualization.PieChart(document.getElementById('piechart-sex'));
        chart.draw(data, options);
    }

    function drawChartEducation() {
        var data = google.visualization.arrayToDataTable([
            ['Education level', 'people'],
            ['Graduate School', <?php echo $def_education_graduateSchool; ?>],
            ['High School', <?php echo $def_education_highSchool; ?>],
            ['Others', <?php echo $def_education_others; ?>],
            ['Uknown', <?php echo $def_education_uknown; ?>],
            ['University', <?php echo $def_education_university; ?>],

        ]);

        // Optional; add a title and set the width and height of the chart
        var options = {
            'title': 'Education Level',
            'width': 550,
            'height': 400
        };

        // Display the chart inside the <div> element with id="piechart"
        var chart = new google.visualization.PieChart(document.getElementById('piechart-education'));
        chart.draw(data, options);
    }

</script>
<!-- END Pie Chart Block -->
</div>

<hr>
</div> <!-- /.container -->
