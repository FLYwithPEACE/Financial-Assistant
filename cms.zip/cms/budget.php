<?php  include "includes/db.php"; ?>
<?php  include "includes/header.php"; ?>


<?php
$personal_money = 1000;




?>



<!-- Navigation -->

<?php  include "includes/navigation.php"; ?>


<!-- Page Content -->
<div class="container">


   <div class="block-title">
        <h2>Budget Assistant</h2>
    </div>

	<hr>
	
	
	

	<?php include "includes/footer.php";?>

</div> <!-- /.container -->
