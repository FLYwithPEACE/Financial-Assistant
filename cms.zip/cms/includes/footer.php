   <!-- Footer -->
        <footer>
<!--
            <div class="row container">
                <div class="col-lg-12">
                    <p>Copyright &copy; Finantial Assistant</p>
                </div>
                 /.col-lg-12 
            </div>
-->
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    

</body>

</html>
