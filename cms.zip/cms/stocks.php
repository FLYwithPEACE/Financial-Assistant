<?php  include "includes/db.php"; ?>
<?php  include "includes/header.php"; ?>


<?php 





    if(isset($_POST['add_stock'])) {

        
        //$comment_author = $_POST['comment_author'];
        $w_stock_name = $_POST['w_stock_name'];



            $query = "INSERT INTO w_stocks (w_stock_name)";

            $query .= "VALUES ('{$w_stock_name}')";

            $create_comment_query = mysqli_query($connection, $query);

            if (!$create_comment_query) {
                die('QUERY FAILED To Submit the stock request' . mysqli_error($connection));


            }



    }

if(isset($_POST['delete'])){
    
    $w_stock_id = escape($_POST['w_stock_id']);
    
    $query = "DELETE FROM w_stocks WHERE w_stock_id = {$w_stock_id} ";
    $delete_query = mysqli_query($connection, $query);
    
    
}



?>


<?php



//$json_dir = "json/".$filename.".json";    
//$string = file_get_contents($json_dir);
//$json_a = json_decode($string, true);
//statement_stocks.json
$json_pred = file_get_contents('./output_stocks_prediction.json');
$json_a_pred = json_decode($json_pred, true);

if ($json_a_pred === null) {
    // deal with error...
    echo "There is an error on the decoding";
}
class Stock_pred{
    public $name;
    public $price;
    public $status;
}


$stocks_pred_array =array();
foreach ($json_a_pred as $id => $atributes) {
    $theStock = new Stock_pred;
    $theStock->name=strval($id);
    $theStock->ROIPrediction=strval($atributes["ROI"]);
    //echo "found ROI of ".$theStock->ROIPrediction;
    
    $theStock->price=strval($atributes["Price"]);
    
//    echo $atributes["Status"];
    $results = "UNDEFINED";
    if(strval($atributes["Status"])=="POSITIVE"){
        
        $results = "Looks safe";
        
    }else{
        $results = "Be careful";
        
    }
    $theStock->status=($results);
    
    
    $theStock->status=strval($results);
//    echo "results out".$theStock->status;
    
     array_push($stocks_pred_array,$theStock);
}

function getClassColorByMessage($message){
    if($message == "Looks safe"){
        return "success";
    }
    return "danger";
}

function setOtherStock_pred($stock_to_research) {
    global $stocks_pred_array;
    foreach ($stocks_pred_array as $currentStock) {
        //echo $currentStock->name;
        if ($currentStock->name == $stock_to_research){
//            echo "Microsoft: ";
//             echo $currentStock->name;
//             echo $currentStock->status;
             return $currentStock;
        }
//        echo "Couldn't find anything";
    
    }
   
    
}

// prediction WORKS!!
//echo "calling";
//$stock_pred_MSFT = setOtherStock_pred("TSLA");
//echo $stock_pred_MSFT->Status;


$json = file_get_contents('./statement_stocks.json');
$json_a = json_decode($json, true);

if ($json_a === null) {
    // deal with error...
    echo "There is an error on the decoding";
}

//Edit this stuff



class Stock
{
    public $name;
    
    public $Bid;
    
    public $currentQtr;
    public $isIndexFund;
    public $PE;
    public $gross_profit;
    public $net_income;
    
    public $currentYear;
    public $fowardDividendYield;
    public $netTangibleAssets;
    public $next5Years;
    public $nextQtr;
    public $totalAssets;
    public $totalCurrentAssets;
    public $totalLiabilities;

    
    
}



$stocks_array =array();
  foreach ($json_a as $id => $atributes) {
 // echo $id;
  // echo " : ";
//  $bid = strval($atributes["PE Ratio (TTM)"]) ;
//  echo $bid;
//      extract($atributes);
      
      $theStock = new Stock;
      
    $theStock->name=strval($id);
      $theStock->PE=strval($atributes["PE Ratio (TTM)"]);
    $theStock->Bid=strval($atributes["Bid"]);
    $theStock->isIndexFund=strval($atributes["isIndexFund"]);
    $theStock->currentQtr=strval($atributes["Current Qtr."]);
    $theStock->currentYear=strval($atributes["Current Year"]);
    $theStock->fowardDividendYield=strval($atributes["Forward Dividend & Yield"]);
    $theStock->grossProfit=strval($atributes["Gross Profit"]);
    $theStock->totalCurrentAssets=strval($atributes["Total Current Assets"]);
    $theStock->netTangibleAssets=strval($atributes["Net Tangible Assets"]);
    $theStock->netIncome=strval($atributes["Net Income"]);
    $theStock->next5Years=strval($atributes["Next 5 Years (per annum)"]);
    $theStock->totalAssets=strval($atributes["Total Assets"]);
    $theStock->totalCurrentAssets=strval($atributes["Total Current Assets"]);
    $theStock->totalLiabilities=strval($atributes["Total Liabilities"]);
      
      


//$cars = array($myCar, $yourCar);
    
    array_push($stocks_array,$theStock);
    
  }
function setOtherStock($stock_to_research) {
    global $stocks_array;
    foreach ($stocks_array as $currentStock) {
        if ($currentStock->name == $stock_to_research){
//            echo "Microsoft: ";
             //echo $currentStock->PE;
             return $currentStock;
        }
    
    }
   
    
}


//THis to get the stock. WORKS
//$currentStock = setOtherStock("AAPL");
//
//echo $currentStock->PE;





?>



<!-- Navigation -->

<?php  include "includes/navigation.php"; ?>


<style>
    .btn-stock-add {
        padding-left: 2%;
    }

    table {
        padding-bottom: 3%;
    }

    .block-title {
        padding-left: 3%;
    }

    .change-url {
        padding-top: 3%;
        color: grey;
        text-align: right;
    }

</style>
<!-- Page Content -->

<div class="container">

    <div class="block-title">
        <h2>Stock Assistant</h2>
    </div>
    <hr>
    <div class="btn-stock-add">
        <form class="form-inline" action="#" method="post" role="form">

            <div class="form-group mx-sm-3 mb-2">
                <input class="form-control" type="text" name="w_stock_name" placeholder="e.g: FB">
            </div>

            <div class="form-group mx-sm-3 mb-2">
                <button type="submit" name="add_stock" class="btn btn-medium btn-primary mb-2">Add Stock</button>
            </div>


        </form>


        <hr>
        <!--    Create the stocks adder.-->


        <!-- Row Styles Block -->
        <div class="block">
            <!-- Row Styles Title -->

            <!-- END Row Styles Title -->

            <!--           Another table-->
            


            <div class=" table-responsive ">
                <table class="table table-hover table-borderless table-vcenter">
                    <thead>
                        <tr>
                            <th>Stock</th>
                            <?php 
                            
                            $name=false;

 $Bid_b=false;
 $isIndexFund_b=false;
 $currentQtr_b=false;
 $currentYear_b=false;
 $fowardDividendYield_b=false;
 $grossProfit_b=false;
 $totalCurrentAssets_b=false;
 $netIncome_b=false;
 $netTangibleAssets_b=false;
 $next5Years_b=false;
 $nextQtr_b=false;
 $PE_b=false;
 $totalAssets_b=false;
 $totalCurrentAssets_b=false;
 $totalLiabilities_b=false;
$stock_prediction_b = false;
$ROIPrediction_b = false;
$price_b=false;
                function getTrueIfChecked($s_cat_status) {
                    if($s_cat_status=="ON"){
                        return true;
                    }else{
                        return false;
                    }

                    
                }        
                
                
                         $query = "SELECT * FROM s_categories";
                        $select_all_posts_query = mysqli_query($connection,$query);

                        while($row = mysqli_fetch_assoc($select_all_posts_query)) {
                            extract($row);
//                            echo "found";
//                                echo $w_stock_name;
                            
//                            $currentStock=setOtherStock($w_stock_name);
//                            
//                            //echo "calling";
//$stock_pred_current = setOtherStock_pred($w_stock_name);

                            
                            
                            if(getTrueIfChecked($s_cat_status)){
                                if("Index Fund"==$s_cat_name){
                                    $isIndexFund_b=true;
                                }
                                
                                if("Bid"==$s_cat_name){
                                    $Bid_b=true;
                                }
                                
                                if("Current QTR"==$s_cat_name){
                                    $currentQtr_b=true;
                                }
                                
                                if("Current Year"==$s_cat_name){
                                    $currentYear_b=true;
                                }
                                
                                if("DIV YIELD"==$s_cat_name){
                                    $fowardDividendYield_b=true;
                                }
                                
                                if("Gross Profit"==$s_cat_name){
                                    $grossProfit_b=true;
                                }
                                
                                if("Net Income"==$s_cat_name){
                                    $netIncome_b=true;
                                }
                                
                                if("Net Tangible Assets"==$s_cat_name){
                                    $netTangibleAssets_b=true;
                                }
                                
                                if("Next 5 Years"==$s_cat_name){
                                    $next5Years_b=true;
                                }
                                
                                if("next Qtr."==$s_cat_name){
                                    $nextQtr_b=true;
                                }
                                
                                if("PE Ratio"==$s_cat_name){
                                    $PE_b=true;
                                }
                                if("total Assets"==$s_cat_name){
                                    $totalAssets_b=true;
                                }
                                
                                if("Total Current Assets"==$s_cat_name){
                                    $totalCurrentAssets_b=true;
                                }
                                
                                if("Total Liabilities"==$s_cat_name){
                                    $totalLiabilities_b=true;
                                }if("Stock Prediction"==$s_cat_name){
                                    $stock_prediction_b=true;
                                }if("ROI Prediction"==$s_cat_name){
                                    $ROIPrediction_b=true;
                                }
                                if("Price"==$s_cat_name){
                                    $price_b=true;
                                }
                                
                            ?>

                            <th><?php echo $s_cat_name; ?></th>



                            <?php 
                        }
                        }
                ?>




                            <th style="width: 80px;" class="text-center"><i class="fa fa-flash"></i></th>

                        </tr>
                    </thead>
                    <tbody>


                        <?php 
                        
                         $query = "SELECT * FROM w_stocks";
                        $select_all_posts_query = mysqli_query($connection,$query);

                        while($row = mysqli_fetch_assoc($select_all_posts_query)) {
                            extract($row);
//                            echo "found";
//                                echo $w_stock_name;
                            
                            $currentStock=setOtherStock($w_stock_name);
                            
                            //echo "calling";
$stock_pred_current = setOtherStock_pred($w_stock_name);
$stock_pred_current->price;
                            
                            ?>
                        <tr class="">
                            <td><?php echo $w_stock_name;?></td>
                            <?php 
                            if($isIndexFund_b){
                                echo "<td>";
                                 echo $currentStock->isIndexFund;
                                echo "</td>";
                            } 
                            if($Bid_b){
                                echo "<td>";
                                 echo $currentStock->Bid;
                                echo "</td>";
                            } 
                            if($currentQtr_b){
                                echo "<td>";
                                 echo $currentStock->currentQtr;
                                echo "</td>";
                                
                            }
                            if($currentYear_b){
                                echo "<td>";
                                 echo $currentStock->currentYear;
                                echo "</td>";
                                
                            } 
                            if($fowardDividendYield_b){
                                echo "<td>";
                                 echo $currentStock->fowardDividendYield;
                                echo "</td>";
                                
                            }
                            if($grossProfit_b){
                                echo "<td>";
                                 echo $currentStock->grossProfit;
                                echo "</td>";
                                
                            }
                            if($totalCurrentAssets_b){
                                echo "<td>";
                                 echo $currentStock->totalCurrentAssets;
                                echo "</td>";
                                
                            }
                            if($netIncome_b){
                                echo "<td>";
                                 echo $currentStock->netIncome;
                                echo "</td>";
                                
                            }
                            if($netTangibleAssets_b){
                                echo "<td>";
                                 echo $currentStock->netTangibleAssets;
                                echo "</td>";
                                
                            }
                            if($next5Years_b){
                                echo "<td>";
                                 echo $currentStock->next5Years;
                                echo "</td>";
                                
                            }
                            if($nextQtr_b){
                                echo "<td>";
                                 echo $currentStock->nextQtr;
                                echo "</td>";
                                
                            }
                            if($PE_b){
                                echo "<td>";
                                 echo $currentStock->PE;
                                echo "</td>";
                                
                            }
                            if($totalAssets_b){
                                echo "<td>";
                                 echo $currentStock->totalAssets;
                                echo "</td>";
                                
                            } 
                            if($totalCurrentAssets_b){
                                echo "<td>";
                                 echo $currentStock->totalCurrentAssets;
                                echo "</td>";
                                
                            }
                            
                            if($stock_prediction_b){
                                ?>
                <td class='<?php echo getClassColorByMessage($stock_pred_current->status) ?>'> <?php echo $stock_pred_current->status;?></td>
                                <?php
                                
                            }
                            
                            if($ROIPrediction_b){
                                ?>
                                <td>
                                <?php
                                
                                
                                //echo "ookno";
                                 echo $stock_pred_current->ROIPrediction;
                                echo "</td>";
                                
                            }
                            
                                
                            
                            
                            
                            ?>
                            <td><?php echo $stock_pred_current->$price;?></td>
                            
                            
                                
                                
                            
                            
                            

                            <form method="post">

                                <input type="hidden" name="w_stock_id" value="<?php echo $w_stock_id ?>">

                                <?php   

            echo '<td><input class="btn btn-effect-ripple btn-xs btn-danger" type="submit" name="delete" value="Delete"></td>';

          ?>


                            </form>
                            <!--

                                <a href="javascript:void(0)" data-toggle="tooltip" title="Delete User" class="btn btn-effect-ripple btn-xs btn-danger"><i class="fa fa-times"></i></a>
-->

                        </tr>


                        <?php
                            

                        }
                        ?>



                    </tbody>
                </table>


            </div>



            <!-- END Row Styles Content -->
        </div>


        <!-- END Row Styles Block -->
    </div>


    <hr>

    <div class="change-url text-secondary">
        <a href="./stock-change.php" class="change-url">
            <p>Would you like to change the table attributes?</p>
        </a>
    </div>

</div>

<?php include "includes/footer.php";?>

</div> <!-- /.container -->
